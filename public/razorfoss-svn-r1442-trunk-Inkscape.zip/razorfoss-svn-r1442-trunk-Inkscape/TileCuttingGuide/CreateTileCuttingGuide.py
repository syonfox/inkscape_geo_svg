#!/usr/bin/env python2


# Copyright 2016 Luke Phillips (lukerazor@hotmail.com)
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

# Extension dirs
# linux:~/.config/inkscape/extensions
# windows: [Drive]:\Program Files\Inkscape\share\extensions

from lxml import etree
import inkex
import copy

GUIDE_MARGIN = 5
STROKE_WIDTH = 0.3
HALF_STROKE = STROKE_WIDTH/2
DEFAULT_FILL = "#ffffff"

CSNS = ""

inkex.NSS[u"cs"] = u"http://www.razorfoss.org/tilecuttingguideextension/"

def PrintDebug(msg):
	inkex.utils.debug(msg)
	
def DebugBBox(bbox):
	return inkex.utils.debug("top: {}, left: {}, width: {}, height: {}".format(bbox.top, bbox.left, bbox.width, bbox.height))

class EffectDimensionProvider():
	def __init__(self, effect):
		self.Effect = effect

		self.Layer = effect.svg.get_current_layer()

	def MMtoUU(self, mmval):
		if hasattr(self.Effect.svg, "unittouu"):
			return str(self.Effect.svg.unittouu("{0}mm".format(mmval)))
		else:
			MM_TO_PIXELS = 3.5433071

			return str(MM_TO_PIXELS * mmval)

def ConvertToSvgColour(int_val):
	hex_str = hex(int(int_val))
	colour = "#" + hex_str[:-2].replace("0x", "").zfill(6)
	opacity = int(hex_str[-2:], 16) / 255 # as a percent
	
	return (colour, opacity)

class TileCuttingGuideCreateEffect(inkex.Effect):
	def __init__(self):
		inkex.Effect.__init__(self)
		self.arg_parser.add_argument("-tw", "--tile_width", type = float, dest = "tile_width")
		self.arg_parser.add_argument("-th", "--tile_height", type = float, dest = "tile_height")
		self.arg_parser.add_argument("-ta", "--tiles_across", type = int, dest = "tiles_across")
		self.arg_parser.add_argument("-td", "--tiles_down", type = int, dest = "tiles_down")
		self.arg_parser.add_argument("-fc", "--group_fill_color", type = ConvertToSvgColour, dest = "group_fill_color")
		self.arg_parser.add_argument("-cc", "--crop_stroke_color", type = ConvertToSvgColour, dest = "crop_stroke_color")
		
		
		self.group = None
		self.dimensionProvider = EffectDimensionProvider(self)

	def CreatePathinMillimetres(self, cmds, style):
		pathStr = ""
		for cmd in cmds:
			pathStr += cmd[0] + " "
			for coord in cmd[1:]:
				pathStr += self.dimensionProvider.MMtoUU(coord) + " "

		pathStr += "z"
		#raise Exception(pathStr)

		attribs = {"style": str(inkex.Style(style)), "d": pathStr}
		etree.SubElement(self.group, inkex.addNS("path","svg"), attribs)

	def CreateRectangleInMillimetres(self, width, height, x, y, style):

		attribs = {
			"style": str(inkex.Style(style)), 
			"height": self.dimensionProvider.MMtoUU(height), 
			"width": self.dimensionProvider.MMtoUU(width), 
			"x": self.dimensionProvider.MMtoUU(x), 
			"y": self.dimensionProvider.MMtoUU(y)
		}
		etree.SubElement(self.group, inkex.addNS("rect","svg"), attribs)

	def effect(self):
				
		bbox_style = {"stroke": "#000000", "stroke-width": STROKE_WIDTH, "fill" : self.options.group_fill_color[0], "opacity": self.options.group_fill_color[1]}
		crop_mark_style = {"stroke": self.options.crop_stroke_color[0], "stroke-width": STROKE_WIDTH, "fill" : "#ffffff", "opacity": self.options.crop_stroke_color[1]}
		self.group = etree.SubElement(self.svg.get_current_layer(), inkex.addNS("g","svg"), {} )
		
		# bounding box
		bbox_width = (self.options.tile_width * self.options.tiles_across) + 2*GUIDE_MARGIN
		bbox_height = (self.options.tile_height * self.options.tiles_down) + 2*GUIDE_MARGIN
		
		self.CreateRectangleInMillimetres(bbox_width, bbox_height, 0, 0, bbox_style)
		
		# tile boxes
		tile_box_styles = [
			{"stroke": "#000000", "stroke-width": 0, "fill" : "#eeeeee"},
			{"stroke": "#000000", "stroke-width": 0, "fill" : "#dedede"}
		]
		for x_idx in range(0, self.options.tiles_across):
			for y_idx in range(0, self.options.tiles_down):
				style_idx = (x_idx + y_idx) % 2
				x_off = GUIDE_MARGIN + x_idx * self.options.tile_width
				y_off = GUIDE_MARGIN + y_idx * self.options.tile_height
				
				self.CreateRectangleInMillimetres(self.options.tile_width, self.options.tile_height, x_off, y_off, tile_box_styles[style_idx])
				
		# vertical cutting guides
		for x_idx in range(0, self.options.tiles_across + 1):
			x_off = GUIDE_MARGIN + x_idx * self.options.tile_width
			self.CreatePathinMillimetres([ ["m", x_off, 0], ["v", GUIDE_MARGIN/2] ], crop_mark_style)
			
			self.CreatePathinMillimetres([ ["m", x_off, bbox_height], ["v", -GUIDE_MARGIN/2] ], crop_mark_style)
			
		# horizontal cutting guides
		for y_idx in range(0, self.options.tiles_down + 1):
			y_off = GUIDE_MARGIN + y_idx * self.options.tile_height
			self.CreatePathinMillimetres([ ["m", 0, y_off], ["h", GUIDE_MARGIN/2] ], crop_mark_style)
			
			self.CreatePathinMillimetres([ ["m", bbox_width, y_off], ["h", -GUIDE_MARGIN/2] ], crop_mark_style)


if __name__ == "__main__":
	creator = TileCuttingGuideCreateEffect()

	creator.run()
