import sys
import os.path
import argparse
import math

import numpy as np
import cv2

MIN_CONTOUR_SIZE = 100

def ProcessImages(input_files, output_dir, background):
	if not os.path.isdir(output_dir):
		print("{} is not a directory".format(output_dir))
		return

	cidx = 0
	for in_file_path in input_files:
		if not os.path.isfile(in_file_path):
			print("{} is not a file".format(in_file_path))
			continue

		print("Processing {}".format(in_file_path))
		image = cv2.imread(in_file_path)
		# create an image with an aplha channel
		image_a = cv2.cvtColor(image, cv2.COLOR_BGR2BGRA)

		# convert the image to grayscale and flip the foreground
		# and background to ensure foreground is now "white" and
		# the background is "black"
		grey = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

		bg_type = background
		if bg_type == "auto":
			sample = grey[0:50, 0:50]
			bg_type = "light"
			if np.mean(sample) < 127:
				bg_type = "dark"

			print(" {} background detected".format(bg_type))

		if bg_type == "light":
			grey = cv2.bitwise_not(grey)

		# threshold the image, setting all foreground pixels to
		# 255 and all background pixels to 0
		bw = cv2.threshold(grey, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]

		# dilate and then erode to "join" the significant pixels together
		kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (25, 25))

		bw = cv2.dilate(bw, kernel, iterations = 1)
		bw = cv2.erode(bw, kernel, iterations = 1)

		# now do the opposite to get rid of small bits of noise
		bw = cv2.erode(bw, kernel, iterations = 1)
		bw = cv2.dilate(bw, kernel, iterations = 1)

		# now find outer contours
		contours, _ = cv2.findContours(bw.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

		for contour in contours:
			# if the contour is big enough i.e. not noise
			x, y, w, h = cv2.boundingRect(contour)
			if w > MIN_CONTOUR_SIZE and h > MIN_CONTOUR_SIZE:
				segment = IsolateContour(image_a, contour)

				outPath = os.path.join(output_dir, "img_{:05d}.png".format(cidx))
				cv2.imwrite(outPath, segment)

				cidx += 1


def IsolateContour(img, contour):
	# first draw the contour on a black mask image
	mask = np.zeros_like(img)
	cv2.drawContours(mask, [contour], contourIdx = 0, color = (255, 255, 255, 255), thickness = -1) # (line)thickness -1 means filled shape

	# apply mask to original image to give isolated pixels
	isolatedImg = cv2.bitwise_and(img, mask)

	# find the bounding rect of our contour and crop to a square based on the largest dimension, but with the same centre
	# this avoids cutting off the card if it decides to rotate it "wrong"
	roi_x, roi_y, roi_w, roi_h = cv2.boundingRect(contour)
	boundingRec = isolatedImg[roi_y:roi_y + roi_h, roi_x:roi_x + roi_w]

	size = max(roi_w, roi_h)
	rotateSquare = np.zeros((size, size, 4), isolatedImg.dtype)

	# NOTE: // is floor division, this may mean we lose a pixel or 2 :)
	copyTop = size // 2 - roi_h // 2
	copyLeft = size // 2 - roi_w // 2
	rotateSquare[copyTop:copyTop + roi_h, copyLeft:copyLeft + roi_w] = boundingRec

	centre = (size // 2, size // 2) # centre of rotateSquare, about which the rotation will occur

	# finally deskew the roi if required
	extract_size, angle = cv2.minAreaRect(contour)[1:]

	rotated = rotateSquare
	# don't bother with less than 0.5 degrees, avoids problem with bug in cv2 where the angle gets reported as -90 (which is against spec)
	if angle > -89.5 and angle < -0.5:
		# NOTE: correction is clockwise
		matrix = cv2.getRotationMatrix2D(centre, angle, 1.0)
		rotated = cv2.warpAffine(rotateSquare, matrix, (size, size), flags=cv2.INTER_CUBIC)

	# now crop the blank edges
	y_nonzero, x_nonzero, _ = np.nonzero(rotated)
	return rotated[np.min(y_nonzero):np.max(y_nonzero), np.min(x_nonzero):np.max(x_nonzero)]

if __name__ == "__main__":
	parser = argparse.ArgumentParser(description="Process scanned images into auto-rotated parts.")
	parser.add_argument("output_dir", help = "The output directory.  Warning! files in the output directory may be overwritten without notice")
	parser.add_argument("input_files", nargs = argparse.REMAINDER, help = "The list of files to process")
	parser.add_argument("--background", "-b", choices=['dark', 'light', 'auto'], default = "auto", help = "How to treat the image background")
	args = vars(parser.parse_args())
	#print(args)

	ProcessImages(args["input_files"], args["output_dir"], args["background"])