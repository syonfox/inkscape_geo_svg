#!/usr/bin/env python2


# Copyright 2016 Luke Phillips (lukerazor@hotmail.com)
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

# Extension dirs
# linux:~/.config/inkscape/extensions
# windows: D:\Program Files\Inkscape\share\extensions

import inkex

def PrintDebug(msg):
	inkex.utils.debug(msg)
	
def DebugBBox(bbox):
	return inkex.utils.debug("left: {}, top: {}, width: {}, height: {}, x: {}, y: {}".format(bbox.left, bbox.top, bbox.width, bbox.height, bbox.x, bbox.y))

def BoundingBoxArea(node):
	bb = node.bounding_box()
	return bb.width * bb.height

def BoundingBoxInUnit(node, unit):
	bb = node.bounding_box()
	
	left = inkex.units.convert_unit(bb.left, unit, node.unit)
	top = inkex.units.convert_unit(bb.top, unit, node.unit)
	
	new_bb = inkex.transforms.BoundingBox(
		inkex.transforms.BoundingInterval(
			left,
			left + inkex.units.convert_unit(bb.width, unit, node.unit)
		),
		inkex.transforms.BoundingInterval(
			top,
			top + inkex.units.convert_unit(bb.height, unit, node.unit)
		)
	)
	
	return new_bb
	
class InsetAlignmentCreateEffect(inkex.Effect):
	def __init__(self):
		inkex.Effect.__init__(self)

		self.arg_parser.add_argument('-a', '--anchor_node', type = str, dest = 'AnchorNode')
		self.arg_parser.add_argument('-v', '--relative_to_v', type = str, dest = 'RelativeToV')
		self.arg_parser.add_argument('-t', '--relative_to_h', type = str, dest = 'RelativeToH')
		self.arg_parser.add_argument('-x', '--inset_x', type = float, dest = 'InsetX')
		self.arg_parser.add_argument('-y', '--inset_y', type = float, dest = 'InsetY')

	def GetPaths(self):
		paths = []

	def effect(self):
		# make sure we have at least 2 nodes selected
		if len(self.options.ids) < 2:
			inkex.utils.debug("You must select at least 2 nodes")
			return

		# pick the achor node
		anchorNodeId = self.options.ids[0] # first selected
		if self.options.AnchorNode ==  "LAST_SEL": # last selected
			anchorNodeId = self.options.ids[-1]
		elif self.options.AnchorNode == "LARGEST": # largest
			anchorNodeId = None
			largestArea = 0
			for hashId, node in self.svg.selected.items():
				nodeArea = BoundingBoxArea(node)
				if nodeArea > largestArea:
					anchorNodeId = node.get_id()
					largestArea = nodeArea

		anchorNode = self.svg.selected[anchorNodeId]

		otherNodes = [n for i, n in self.svg.selected.items() if n.get_id() != anchorNodeId]
		
		# for every other Node
		for node in otherNodes:
			# calculate the offsets in the nodes units
			insetH = inkex.units.convert_unit(self.options.InsetX, node.unit, "mm")
			insetV = inkex.units.convert_unit(self.options.InsetY, node.unit, "mm")
						
			bbox = node.bounding_box()
			#get the anchor node bbox in nodes unit
			anchorBBox = BoundingBoxInUnit(anchorNode, node.unit)
			
			# sort out vertical offset
			deltaV = (anchorBBox.top - bbox.top) + insetV # ALIGN TOP
			if self.options.RelativeToV in "BOTTOM":
				deltaV = (anchorBBox.bottom - bbox.bottom) - insetV # ALIGN BOTTOM
			if self.options.RelativeToV == "CENTRE":
				deltaV = (anchorBBox.top + anchorBBox.height/2 - bbox.height/2) - bbox.top # ALIGN CENTRE

			# sort out the horizontal offset
			deltaH = (anchorBBox.left - bbox.left) + insetH # ALIGN LEFT
			if self.options.RelativeToH == "RIGHT":
				deltaH = (anchorBBox.right - bbox.right) - insetH # ALIGN RIGHT
			if self.options.RelativeToH == "MIDDLE":
				deltaH = (anchorBBox.left + anchorBBox.width/2 - bbox.width/2) - bbox.left # ALIGN MIDDLE
				
			tform = inkex.Transform("translate({0}, {1})".format(deltaH, deltaV))
			node.transform = tform @ node.transform
		
if __name__ == '__main__':
	creator = InsetAlignmentCreateEffect()

	creator.run()
