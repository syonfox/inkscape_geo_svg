#!/usr/bin/env python2


# Copyright 2016 Luke Phillips (lukerazor@hotmail.com)
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

# Extension dirs
# linux:~/.config/inkscape/extensions
# linux flatpack:~/.var/app/org.inkscape.Inkscape/config/inkscape/extensions
# windows: D:\Program Files\Inkscape\share\extensions

import inkex
import os.path
import subprocess
import copy

def PrintDebug(msg):
	inkex.utils.debug(msg)
	
def DebugBBox(bbox):
	return inkex.utils.debug("top: {}, left: {}, width: {}, height: {}".format(bbox.top, bbox.left, bbox.width, bbox.height))

class PdfPageExporterEffect(inkex.Effect):
	def __init__(self):
		inkex.Effect.__init__(self)

		self.arg_parser.add_argument('-t', '--export_type', type = str, dest = 'export_type')
		
	def effect(self):
		if self.svg_path() == "":
			inkex.utils.errormsg("File must be saved to disc before exporting")
			return		
				
		if self.options.export_type == "1":
			self.ExportGroups()
		elif self.options.export_type == "2":
			self.ExportLayers()
		else:
			inkex.utils.errormsg("Unknown export type")
			return

		inkex.utils.errormsg("Finished")
			
	def WriteExportFile(self, doc, exportFileName):
		
		tmpFilePath = os.path.join(self.svg_path(), "tmp.svg")
		exportFilePath = os.path.join(self.svg_path(), exportFileName)
		
		# write out temp svg
		doc.write(tmpFilePath)
		
		# call inkscape to convert to pdf. NOTE: format is inferred from file extension		
		inkex.command.inkscape(tmpFilePath, "--export-filename=" + exportFilePath)
		
		# useful for debugging
		#PrintDebug(subprocess.run([self.options.inkscape_path, "--export-filename=" + exportFilePath, tmpFilePath]))
		
		#clean up tmp file
		if os.path.isfile(tmpFilePath):
			os.remove(tmpFilePath)
			pass
						
	def ExportGroups(self):
		# make sure we have at least 1 node selected
		if len(self.options.ids) < 1:
			inkex.utils.errormsg("You must select at least 1 group or object")
			return

		page = 1
		for nodeId in self.options.ids:
			node = self.svg.selected[nodeId]

			# determine file name
			outFile = "Page_{:03d}.pdf".format(page)
			page += 1

			#preserve original transform
			origTrans = node.transform
			
			# calculate the centering transform
			bbox = node.bounding_box()
			
			deltaX = -bbox.left + (inkex.units.convert_unit(self.svg.viewport_width, node.unit, "px")/2 - bbox.width/2)
			deltaY = -bbox.top + (inkex.units.convert_unit(self.svg.viewport_height, node.unit, "px")/2 - bbox.height/2)
			
			# apply centering transform, NOTE you *must* have the translate first!!!!!!!!!
			node.transform = inkex.Transform(translate=(deltaX, deltaY)) @ origTrans
			
			self.WriteExportFile(self.document, outFile)
	
			# return group to its original position
			node.transform = origTrans
			
	def ExportLayers(self):
		doc = copy.deepcopy(self.document) # take a copy so we don't disturb the original
		
		svg_layers = doc.xpath('//svg:g[@inkscape:groupmode="layer"]', namespaces=inkex.NSS)
		layers = []

		# enumerate the layers
		for layer in svg_layers:
			label_attrib_name = "{%s}label" % layer.nsmap['inkscape']
			if label_attrib_name not in layer.attrib:
				continue

			lay = {"layer": layer,
				   "type": "EXPORT"
				  }
			
			layer_label = layer.attrib[label_attrib_name]

			if layer_label.upper().endswith("_HIDE"):
				lay["type"] = "HIDE"
			elif layer_label.upper().endswith("_SHOW"):
				lay["type"] = "SHOW"
			
			layers.append(lay)

		# init all layers
		for lay in layers:
			if lay["type"] == "SHOW":
				lay["layer"].attrib['style'] = 'display:inline'
			else:
				lay["layer"].attrib['style'] = 'display:none'
				
		# export
		page = 1
		for lay in layers:
			outFile = "Page_{:03d}.pdf".format(page)
			
			if lay["type"] == "EXPORT":
				lay["layer"].attrib['style'] = 'display:inline'
				
				self.WriteExportFile(doc, outFile)
				page += 1
				
				lay["layer"].attrib['style'] = 'display:none'

if __name__ == '__main__':
	exporter = PdfPageExporterEffect()

	exporter.run()
